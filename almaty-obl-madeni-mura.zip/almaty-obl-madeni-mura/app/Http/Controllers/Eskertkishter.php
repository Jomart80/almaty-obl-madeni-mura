<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class Eskertkishter extends Controller
{
    public function eskertkishter()
    {
        return view('eskertkishter');
    }
	
	public function balqash_audany()
	{
		return view('eskertkishter.balqash-audany');
	}
	
	public function balqash_audany_boltirik_sheshen_eskertkishi()
	{
		return view('eskertkishter.balqash-audany.boltirik-sheshen-eskertkishi');
	}
	
	public function rayimbek_audany_rayimbek_batyrdyng_memorialdyq_kesheni()
	{
		return view('eskertkishter.rayimbek-audany.rayimbek-batyrdyng-memorialdyq-kesheni');
	}
}
