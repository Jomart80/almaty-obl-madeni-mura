<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {   return view('welcome');});

Route::get('/eskertkishter', 'App\Http\Controllers\Eskertkishter@eskertkishter');

//Balqash
Route::get('/eskertkishter/balqash-audany', 'App\Http\Controllers\Eskertkishter@balqash_audany');
Route::get('/eskertkishter/balqash-audany/boltirik-sheshen-eskertkishi', 'App\Http\Controllers\Eskertkishter@balqash_audany_boltirik_sheshen_eskertkishi');

//Rayimbek
Route::get('/eskertkishter/rayimbek', 'App\Http\Controllers\Eskertkishter@rayimbek');
Route::get('/eskertkishter/rayimbek-audany/rayimbek-batyrdyng-memorialdyq-kesheni', 'App\Http\Controllers\Eskertkishter@rayimbek_audany_rayimbek_batyrdyng_memorialdyq_kesheni');

//Jambyl
Route::get('/eskertkishter/jambyl', 'App\Http\Controllers\Eskertkishter@jambyl');

