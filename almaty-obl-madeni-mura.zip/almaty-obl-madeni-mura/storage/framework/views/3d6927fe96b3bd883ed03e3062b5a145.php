<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>"АЛМАТЫ ОБЛЫСТЫҚ ТАРИХИ-МӘДЕНИ МҰРАНЫ ҚОРҒАУ ЖӨНІНДЕГІ ОРТАЛЫҚ" КММ</title>
	<!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
	<!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap" rel="stylesheet">
	<!-- MDB -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css" rel="stylesheet">
	
</head>
<!DOCTYPE html>
<html>
<head>
  <title>"АЛМАТЫ ОБЛЫСТЫҚ ТАРИХИ-МӘДЕНИ МҰРАНЫ ҚОРҒАУ ЖӨНІНДЕГІ ОРТАЛЫҚ" КММ</title>
</head>
<body style="background-color: #F3F4F5">
  <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!-- Container wrapper -->
  <div class="container-fluid">
    <!-- Toggle button -->
    <button
      class="navbar-toggler"
      type="button"
      data-mdb-toggle="collapse"
      data-mdb-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      
    </button>

    <!-- Collapsible wrapper -->
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <!-- Navbar brand -->
      
      <!-- Left links -->
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="/mekeme-turaly"><strong>Мекеме тарихы</strong></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"><strong>Ескерткіштер</strong></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"><strong>Актілер</strong></a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="#"><strong>Атқарылған жұмыстар</strong></a>
        </li>
		  <li class="nav-item">
          <a class="nav-link" href="#"><strong>Қазақстанның киелі жерлері</strong></a>
        </li>
		  <li class="nav-item">
          <a class="nav-link" href="#"><strong>Жаңалықтар</strong></a>
        </li>
		   <li class="nav-item">
          <a class="nav-link" href="#"><strong>Галерея</strong></a>
        </li>
      </ul>
      <!-- Left links -->
    </div>
    <!-- Collapsible wrapper -->
	  <!-- Right elements -->
    <div class="d-flex align-items-center">
      <!-- Icon -->
      	<a class="text-reset me-3" href="#">
        <i class="flag flag-russia"></i>
      	</a>
	 	<a class="text-reset me-3" href="#">
        <i class="flag flag-england"></i>
     	</a>
  </div>
  <!-- Container wrapper -->
</nav>
<!-- Navbar -->
  <div class="p-2"></div>
  <div class="container">
    <div class="card hoverable p-1" style="border-radius:10px;">
      <div class="card-body">
		  <div class="container">
          <div class="row">
            <div class="col-2"><img src="<?php echo e('/images/gerb.png'); ?>" class="img-fluid" alt="Герб"></div>
            <div class="col-10 d-flex align-items-center justify-content-center">
              <strong>"АЛМАТЫ ОБЛЫСТЫҚ ТАРИХИ-МӘДЕНИ МҰРАНЫ ҚОРҒАУ ЖӨНІНДЕГІ ОРТАЛЫҚ" КММ</strong>
            </div>
        </div>
			  </div>
      </div>
    </div>
  </div>
	<div class="p-2"></div>
  	<div class="container">
    <div class="card hoverable p-1" style="border-radius:10px;">
      <div class="card-body">
        <div class="container">
          <div class="row">
              <strong>Ескерткіштер</strong>
			  <hr>
			  <p>Мемлекеттік тілде:</p>
			  <p>
				Ескерткіштер
			  
            </div>
          </div>
        </div>
      </div>
    </div>
</body>
</html>
	<!-- MDB -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.js"></script>
</html><?php /**PATH /var/www/vhosts/almaty-obl-madeni-mura.kz/almaty-obl-madeni-mura/resources/views/eskertkishter.blade.php ENDPATH**/ ?>